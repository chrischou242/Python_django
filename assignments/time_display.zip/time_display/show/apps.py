from django.apps import AppConfig


class ShowConfig(AppConfig):
    name = 'show'
